package com.example.mergrecycle;

public class Anime {
    private String title, genre, year;

    public Anime(){

    }

    public Anime(String title, String genre, String year){
        this.title = title;
        this.genre = genre;
        this.year = year;
    }

    public String getTitle(){
        return title;
    }

    public void setTitle(String name){
        this.title = name;
    }

    public String getGenre(){
        return genre;
    }

    public void setGenre(String name){
        this.genre = name;
    }

    public String getYear(){
        return year;
    }

    public void setYear(String name){
        this.year = name;
    }
}

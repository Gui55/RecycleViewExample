package com.example.mergrecycle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AnimeAdapter extends RecyclerView.Adapter<AnimeAdapter.MyViewHolder> {
    private List<Anime> animeList = new ArrayList<>();
    private RecyclerView recyclerView;
    private AnimeAdapter aAdapter;

    public AnimeAdapter(List<Anime> animeList){
        this.animeList = animeList;
    }

    @NonNull
    @Override
    public AnimeAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.second_xml,
                parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull AnimeAdapter.MyViewHolder holder, int position) {
        Anime anime = animeList.get(position);
        holder.title.setText(anime.getTitle());
        holder.genre.setText(anime.getGenre());
        holder.year.setText(anime.getYear());
    }

    @Override
    public int getItemCount() {
        return animeList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        public TextView title, year, genre;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            title = (TextView)itemView.findViewById(R.id.textViewA);
            year = (TextView)itemView.findViewById(R.id.textViewB);
            genre = (TextView)itemView.findViewById(R.id.textViewC);
        }
    }
}

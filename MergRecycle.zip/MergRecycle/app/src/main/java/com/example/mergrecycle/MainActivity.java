package com.example.mergrecycle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toolbar;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<Anime> animeList = new ArrayList<>();
    private RecyclerView recyclerView;
    private AnimeAdapter aAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = (RecyclerView)findViewById(R.id.recycle);

        aAdapter = new AnimeAdapter(animeList);
        RecyclerView.LayoutManager aLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(aLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(aAdapter);

        prepareMovieData();
    }

    private void prepareMovieData() {
        Anime anime = new Anime("Re: Zero kara Hajimeru Isekai Seikatsu",
                "Adventure/Isekai", "2016");
        animeList.add(anime);

        anime = new Anime("Higurashi no Naku Koro ni", "Horror", "2006");
        animeList.add(anime);

        anime = new Anime("Karakai Jouzu no Takagi-san", "Slice of Life", "2018");
        animeList.add(anime);

        aAdapter.notifyDataSetChanged();
    }
}
